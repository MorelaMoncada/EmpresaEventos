package academia;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;

public class Cursos 
{
    //propios y privados
    private String IdCurso, Nombre, Horario, Aula,Dia;
    private int Cupos, Disponibilidad;
    private LocalDate FechaIni, FechaFin;

    public Cursos(String IdCurso, String Nombre, String Horario, String Aula, String Dia, int Cupos, int Disponibilidad, LocalDate FechaIni, LocalDate FechaFin) {
        this.IdCurso = IdCurso;
        this.Nombre = Nombre;
        this.Horario = Horario;
        this.Aula = Aula;
        this.Dia = Dia;
        this.Cupos = Cupos;
        this.Disponibilidad = Disponibilidad;
        this.FechaIni = FechaIni;
        this.FechaFin = FechaFin;
    }

    public Cursos() {
    }

    public Cursos IngresarDatos(String idc)
    {
        //variables auxiliares y locales
      String Nom, Hor, Au,Di;
      int Cup, Dispo;
      LocalDate FechaI, FechaF;
      Nom=Validaciones.LeerString("Nombre del curso: ");
      Hor=Validaciones.LeerString("Horario del curso: ");  
      Au=Validaciones.LeerString("Aula del curso: "); 
      Di=Validaciones.LeerDia();
      Cup=Validaciones.LeerInt("Número de cupos del curso: ");
      Dispo=Validaciones.LeerInt("Disponibilidad del curso: ");
      FechaI=Validaciones.LeerFecha("Fecha de inicio de curso: dd/MM/yyyy");
      FechaF=Validaciones.LeerFecha("Fecha de final del curso: dd/MM/yyyy");
      Cursos objCur=new Cursos(idc,Nom,Hor, Au,Di,Cup, Dispo,FechaI, FechaF);
      return objCur;
    }//fin de ingresar
    
    public String EstructuraReg() {
        return IdCurso + "," + Nombre + "," + Horario + "," + Aula + "," + Dia + "," + Cupos + "," + Disponibilidad + "," + FechaIni + "," + FechaFin;
    }
        
    @Override
    public String toString() {
        return "Id Curso=" + IdCurso + ", Nombre=" + Nombre + ", Horario=" + Horario + ", Aula=" + Aula + ", Dia=" + Dia + ", Cupos=" + Cupos + ", Disponibilidad=" + Disponibilidad + ", Fecha Inicio=" + FechaIni + ", Fecha Final=" + FechaFin;
    }

    public String getIdCurso() {
        return IdCurso;
    }

    public void setIdCurso(String IdCurso) {
        this.IdCurso = IdCurso;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getHorario() {
        return Horario;
    }

    public void setHorario(String Horario) {
        this.Horario = Horario;
    }

    public String getAula() {
        return Aula;
    }

    public void setAula(String Aula) {
        this.Aula = Aula;
    }

    public String getDia() {
        return Dia;
    }

    public void setDia(String Dia) {
        this.Dia = Dia;
    }

    public int getCupos() {
        return Cupos;
    }

    public void setCupos(int Cupos) {
        this.Cupos = Cupos;
    }

    public int getDisponibilidad() {
        return Disponibilidad;
    }

    public void setDisponibilidad(int Disponibilidad) {
        this.Disponibilidad = Disponibilidad;
    }

    public LocalDate getFechaIni() {
        return FechaIni;
    }

    public void setFechaIni(LocalDate FechaIni) {
        this.FechaIni = FechaIni;
    }

    public LocalDate getFechaFin() {
        return FechaFin;
    }

    public void setFechaFin(LocalDate FechaFin) {
        this.FechaFin = FechaFin;
    }
    
    
}//fin clase curso
