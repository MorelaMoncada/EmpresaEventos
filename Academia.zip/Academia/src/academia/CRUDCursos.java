package academia;

import java.time.LocalDate;
import javax.swing.JOptionPane;

public class CRUDCursos 
{
  
    /*Metodo que busca un codigo de curso en el archivo plano y si lo encuentra
    retorna verdadero, sino lo encuentra retorna falso*/
        
    public boolean Buscar(Archivos objArch, String Idc) {
        boolean sw = false;
        try {
            //locales auxiliares para extraer la informacion del archivo
            String code, nom, horario, aula, dia;
            LocalDate fechIn, fechFn;
            int cupos, disp;
           
            String Reg[];//para tomar la linea String como vector de datos y facilitar el trabajo con el registro
            //se abre el archivo modo lectura y se imprime el mensaje de apertura que retorna
            objArch.AbrirArchivoModoLectura("Cursos.txt");
            //se invoca al metodo de leer registro con 9 atributos para el vector de la linea o registro del archivo plano 
            //se recibe el texto en Reg
            Reg = objArch.LeerRegistro(9);
            //mientras existan datos en el archivo
            while (Reg != null) //mientras not EOF()
            {
                /*los datos del Reg que se obtiene del archivo plano de texto se 
                asignan a las variables auxiliares locales para su facil manejo 
                como posiciones del vector String*/
                code  = Reg[0];
                nom = Reg[1];
                horario = Reg[2];
                aula = Reg[3];
                dia = Reg[4];
                cupos = Integer.parseInt(Reg[5]);
                disp = Integer.parseInt(Reg[6]);
                fechIn = LocalDate.parse(Reg[7]);
                fechFn =LocalDate.parse(Reg[8]);
              
                //si el id del curso que extraimos del archivo en Reg es igual al id del curso que se esta buscando
                if (code.equals(Idc)) 
                {
                    sw = true;
                }//fin si
                //se lee el otro registro para que termine secuencialmente la lectura del archivo texto
                Reg = objArch.LeerRegistro(9);
            }//fin mientras
            //cerramos el archivo plano de texto en modo lectura
            objArch.CerrarArchivoModoLectura();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "***Archivo leido y cerrado correctamente***");
        }
        return sw;
    }//fin de buscar
    

    /*--------------------------------------------------------------*/
    
    
    /* Metodo que a partir de un id  lo busca en el archivo y si no lo encuentra
     lo graba fisicamente con sus otros datos en el archivo y si lo encuentra muestra un mensaje 
     y no graba de nuevo  porque estaría repetido */
    
    public void IngresarCurso(Archivos objArch, String idc) {
        Cursos objC = new Cursos();
        //se invoca el metodo buscar   
        if (Buscar(objArch, idc) == false) {
            //se llama el metodo de ingresar datos de Cursos que recibe id y retorna el objeto curso 
            objC = objC.IngresarDatos(idc);
            //se invoca el metodo que graba fisicamente en el archivo
            GrabarCurso(objArch, objC);
        } else {
            JOptionPane.showMessageDialog(null, "*****Curso YA existe en el archivo*****");

        }
    } //FIN INGRESAR CURSO
    
    
    /*--------------------------------------------------------------*/

    
    /*metodo que graba fisicamente el registro en el archivo*/

    public void GrabarCurso(Archivos objArchivos, Cursos objC) {
        try {
            String cadena = "";
            objArchivos.AbrirArchivoModoEscritura("Cursos.txt");
            /*con el objeto que llega se invoca el metodo para la estructura del registro
            separado por comas y se recibe en la cadena para grabarla en el archivo*/
            cadena = objC.EstructuraReg();
            //la cadena separada por comas se graba persistentemente en memoria
            objArchivos.EscribirRegistro("" + cadena);
            objArchivos.CerrarArchivoModoEscritura();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "*****SE GRABA EN EL ARCHIVO DE CURSOS*****");
        }

    }//FIN GRABAR CURSO
    
    
    /*--------------------------------------------------------------*/
    

    /*metodo que muestra todo el contenido del archivo*/
    
    public String MostrarTodo(Archivos objArch) {
        String cadena = "";
        try {
            //locales auxiliares para extraer la informacion del archivo
            String code, nom, horario, aula,  dia;
            LocalDate fechIn, fechFn;
            int cupos, disp;
           
            String Reg[];//para tomar la linea String como vector de datos y facilitar el trabajo con el registro
            //se abre el archivo modo lectura y se imprime el mensaje de apertura que retorna
            JOptionPane.showMessageDialog(null, "" + objArch.AbrirArchivoModoLectura("Cursos.txt"));
            //se invoca al metodo de leer registro con 6 atributos para el vector de la linea o registro del archivo plano 
            //se recibe el texto en Reg
            Reg = objArch.LeerRegistro(9);
            //mientras existan datos en el archivo
            while (Reg != null) //mientras not EOF()
            {
               /*los datos del Reg que se obtiene del archivo plano de texto se 
                asignan a las variables auxiliares locales para su facil manejo 
                como posiciones del vector String*/
                code  = Reg[0];
                nom = Reg[1];
                horario = Reg[2];
                aula = Reg[3];
                dia = Reg[4];
                cupos = Integer.parseInt(Reg[5]);
                disp = Integer.parseInt(Reg[6]);
                fechIn = LocalDate.parse(Reg[7]);
                fechFn =LocalDate.parse(Reg[8]);
               
                Cursos objC = new Cursos(code, nom, horario, aula, dia, cupos, disp, fechIn, fechFn);
                cadena = cadena + objC.toString() + "\n";
                Reg = objArch.LeerRegistro(9);
            }//fin mientras  
            objArch.CerrarArchivoModoLectura();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "***Archivo leído y cerrado correctamente*****");
        }
        return cadena;
     } //FIN MOSTRAR TODO EL ARCHIVO
    
    
    /*--------------------------------------------------------------*/


    public Object Consultar(Archivos objar,String idc)   
      {
          Cursos objC=null;//variable locales para el retorno
          if(Buscar(objar, idc)==true)//se encuentra el dato en el archivo
          {
              try {
                 //locales auxiliares para extraer la informacion del archivo
                 String code, nom, horario, aula, dia;
                 LocalDate fechIn, fechFn;
                 int cupos, disp;
                 
                 String Reg[];//para tomar la linea String como vector de datos y facilitar el trabajo con el registro
                 //se abre el archivo modo lectura y se imprime el mensaje de apertura que retorna
                 JOptionPane.showMessageDialog(null, "" + objar.AbrirArchivoModoLectura("Cursos.txt"));
                 //se invoca al metodo de leer registro con 9 atributos para el vector de la linea o registro del archivo plano 
                 //se recibe el texto en Reg
                 Reg = objar.LeerRegistro(9);
                 //mientras existan datos en el archivo
                 while (Reg != null) //mientras not EOF()
                 {
                    /*los datos del Reg que se obtiene del archivo plano de texto se 
                     asignan a las variables auxiliares locales para su facil manejo 
                     como posiciones del vector String*/
                        code  = Reg[0];
                        nom = Reg[1];
                        horario = Reg[2];
                        aula = Reg[3];
                        dia = Reg[4];
                        cupos = Integer.parseInt(Reg[5]);
                        disp = Integer.parseInt(Reg[6]);
                        fechIn = LocalDate.parse(Reg[7]);
                        fechFn =LocalDate.parse(Reg[8]);

                     if(idc.equals(code))//se encuentra el id en el registro
                     {
                         objC = new Cursos(code, nom, horario, aula, dia, cupos, disp, fechIn, fechFn);
                         
                     }//fin si
                     Reg = objar.LeerRegistro(9);
                 }//fin mientras  
                 objar.CerrarArchivoModoLectura();
             } catch (Exception e) {
                 JOptionPane.showMessageDialog(null, "***Archivo leído y cerrado correctamente*****");
             }
          }else{//No se encuentra
              JOptionPane.showMessageDialog(null,"Dato a consultar en el archivo NO existe");
          }//fin si
       return  objC;//retorna en blanco o el curso
    }//fin consultar
    
    
    /*--------------------------------------------------------------*/

    
    /*metodo que retorna el numero de registros del archivo*/
    
    public int ContarRegistros(Archivos objArch) {
             int cont = 0;
             try {
                 String code, nom, horario, aula, dia;
                 LocalDate fechIn, fechFn;
                 int cupos, disp;

                 String Reg[];//para tomar la linea String como vector de datos y facilitar el trabajo con el registro
                 //se abre el archivo modo lectura y se imprime el mensaje de apertura que retorna
                 JOptionPane.showMessageDialog(null, "" + objArch.AbrirArchivoModoLectura("Cursos.txt"));
                 //se invoca al metodo de leer registro con 9 atributos para el vector de la linea o registro del archivo plano 
                 //se recibe el texto en Reg
                 Reg = objArch.LeerRegistro(9);
                 //mientras existan datos en el archivo
                 while (Reg != null) //mientras not EOF()
                 {
                     /*los datos del Reg que se obtiene del archivo plano de texto se 
                     asignan a las variables auxiliares locales para su facil manejo 
                     como posiciones del vector String*/
                     code  = Reg[0];
                     nom = Reg[1];
                     horario = Reg[2];
                     aula = Reg[3];
                     dia = Reg[4];
                     cupos = Integer.parseInt(Reg[5]);
                     disp = Integer.parseInt(Reg[6]);
                     fechIn = LocalDate.parse(Reg[7]);
                     fechFn =LocalDate.parse(Reg[8]);
                     cont++;
                     Reg = objArch.LeerRegistro(9);
                 }
                 objArch.CerrarArchivoModoLectura();
             } catch (Exception e) {
                 JOptionPane.showMessageDialog(null, "***Archivo leido y cerrado correctamente*****");
             }
             return cont;
         }
  
    
 
} //FIN CLASE
