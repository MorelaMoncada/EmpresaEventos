
package academia;

import javax.swing.JOptionPane;

public class ListaSimple 
{
    //atributos propios y privados
    private Nodo Start, End;

    //auxiliares para movimiento y busqueda
    Nodo q, p, t;
    
    //condiciones iniciales de lista simple
    public ListaSimple() 
    {
        Start=null;
        End=null;
    }

    /*metodo para validar si la lista esta vacia 
    o tiene datos, retorna verdadero si no hay datos*/
    public boolean IsEmpty()
    {
        if(Start==null)
            return true;
        else
            return false;
    }//fin de IsEmpty
    
    /*este metodo recibe un dato tipo object y crea los 
    nodos simples por el inicio o sea queda señalado por 
    el apuntador start el que va ingresando*/
    public void CrearPorInicio(Object d)
    {
        if(IsEmpty()==true)//lista vacia se crea primer nodo
        {
          setStart(new Nodo(d)); 
          setEnd(getStart());
        }
        else
        {
            setStart(new Nodo(d,getStart()));
        }//fin si
    }//fin de crear por inicio
    
     /*este metodo recibe un dato tipo object y crea los 
    nodos simples por el final o sea queda señalado por 
    el apuntador end el que va ingresando*/
    public void CrearPorFinal(Object d)
    {
         if(IsEmpty()==true)//lista vacia se crea primer nodo
        {
          setStart(new Nodo(d)); 
          setEnd(getStart());
        }
        else
        {
            getEnd().setSig(new Nodo(d));
            setEnd(getEnd().getSig());
        }//fin si
       
    }//fin de crear por final
 

   
 //retorna una cadena con toda la información de la lista desde el inicio
 public String ConcatenarDesdeInicio()      
 {
     String texto="";
      if(IsEmpty()==false)//lista NO esta vacia, hay datos
      {
          q=getStart();
          while(q!=null)//mientras existan datos para señalar
          {
              texto=texto+q.getDato().toString()+"\n";
              q=q.getSig();//adelanto en la lista, si falta esta instruccion NO avanza ni llega a null
          }//fin mientras
          
      }
      return texto;    
 }//fin imprimir desde inicio
   
   

/*metodo que busca por la id un curso en la lista,
 retorna verdadero si lo encuentra y ademas deja el apuntador
 p en el dato, y al apuntador t atras de p, y retorna falso en 
 caso de no encontrarlo*/
    public boolean Buscar(String idc)
    {
       if(IsEmpty()==false)//si hay datos
       {
         String IdCu;//variable que debemos usar para capturar el id  
         p=getStart();//colocamos el apuntador al inicio
         IdCu=((Cursos)p.getDato()).getIdCurso();/*tomamos el id de curso
         que esta en el nodo para que no haga la pregunta con p en null!! esto
         NO es necesario en el algoritmo porque es un problema de programacion 
         de java no del análisis*/
         while(p!=null&&!(IdCu.equalsIgnoreCase(idc)))
         {
             t=p;//ubicamos al apuntador t atras de p
             p=p.getSig();//p adelanta en la lista
             if(p!=null)/*si hay aun datos para tomar otro id, esto 
                 no lo tenemos que hacer en el algoritmo*/
                 IdCu=((Cursos)p.getDato()).getIdCurso();
         }//fin mientras
       }
       if(p==null)//recorrió toda la lista y no lo encuentra
           return false;
       else//p quedo ubicada en la lista en el dato buscado
           return true;
    }//fin buscar

     /* Este método parte de que hay algún dato en la lista, e inserta el dato
que recibe de primero en la lista existente (mueve el apuntador Start)*/
public void InsertarStart( Object info)
{
    if (IsEmpty()==false) //si hay algun dato
    {
        setStart(new Nodo(info,getStart()));
    }//fin si 
}//fin insertar en start

/*Este método parte de que hay algún dato en la lista, e inserta 
el dato que recibe de último en la lista existente (mueve el apuntador End)*/
public void InsertarEnd(Object info)
{
    if (IsEmpty()==false) 
    {
 	getEnd().setSig(new Nodo(info));
	setEnd(getEnd().getSig());
    }//fin si 
}//fin insertar en el final

public void InsertarAntes(String IdRef, Object CurIns)
{
if(IsEmpty()==false)
{
	if(Buscar(IdRef)==true)
        {
		if(getStart()==p)
		     InsertarStart(CurIns);
		else
		      t.setSig(new Nodo(CurIns,p));
		//fin si
        }else
		JOptionPane.showMessageDialog(null,"El dato referencia NO esta en la lista");
        //fin si
}//Fin si
}//Fin insertar antes	
public void InsertarDespues(String IdRef, Object CurIns)
{
if(IsEmpty()==false)
{
	if(Buscar(IdRef)==true)
        {
		if(getEnd()==p)
		     InsertarEnd(CurIns);
		else
		      p.setSig(new Nodo(CurIns,p.getSig()));
		//fin si
        }else
		JOptionPane.showMessageDialog(null,"El dato referencia NO esta en la lista");
	//Fin si
}//Fin si
}//Fin insertar antes	

public Object LiberarEnd()
{
Object info=null;
if(IsEmpty()==false)
{
    info=((Cursos)getEnd().getDato()).getIdCurso();
    if(getStart().getSig()==null)
    {
        getStart().finalize();
        getEnd().finalize();
        Start=End=null;
        JOptionPane.showMessageDialog(null,"la lista quedo vacia");
    }
    else{
       //se pierde el retorno del buscar porque lo que necesitamos es ubicar a t y a p
    	Buscar(((Cursos)getEnd().getDato()).getIdCurso());
        setEnd(t);
	p.finalize();
	getEnd().setSig(null);
    }//fin si
}//fin si
return info;
}//fin liberar ultimo

public Object LiberarStart()
{
Object info=null;
if(IsEmpty()==false)
{
    info=((Cursos)getStart().getDato()).getIdCurso();
    if(getStart().getSig()==null)
    {
        getStart().finalize();
        getEnd().finalize();
        Start=End=null;
        JOptionPane.showMessageDialog(null,"la lista quedo vacia");
    }
    else{
       q=getStart();
       setStart(getStart().getSig());
       q.finalize();
    }//fin si
}//fin si
return info;
}//fin liberar ultimo

public void LiberarDato(String idc)
{
if(IsEmpty()==false)
{
 if(Buscar(idc)==true)
 {
    if(p==getStart())
    {
           LiberarStart();
    }
    else{
          if(p==getEnd())
              LiberarEnd();
          else
          {
                t.setSig(p.getSig());
                p.finalize();
          }//fin si
    }//fin si	
    JOptionPane.showMessageDialog(null,"El dato fue eliminado de la lista");
 }else
      JOptionPane.showMessageDialog(null,"Curso no existe en la lista");
// Fin si
}//Fin si
}//Fin liberarDato




    public Nodo getStart() {
        return Start;
    }

    public void setStart(Nodo Start) {
        this.Start = Start;
    }

    public Nodo getEnd() {
        return End;
    }

    public void setEnd(Nodo End) {
        this.End = End;
    }
    
    
    
    
    
    
    
}//fin de lista simple
