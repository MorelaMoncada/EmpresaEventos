
package academia;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import javax.swing.JOptionPane;


public class Validaciones 
{
    public static int LeerOpcion(String mensaje, int tope)
    {
     int op=0;   
     do{
            try{
            op=Integer.parseInt(JOptionPane.showInputDialog(mensaje));
            if(op<=0||op>tope)
                JOptionPane.showMessageDialog(null,"Debe ingresar número entre 1 y "+tope);
            }catch(Exception e)
            {
                 JOptionPane.showMessageDialog(null,"Error NO debe digitar letras");
            }
            
            }while(op<=0||op>tope);
     return op;
    }//fin de leer opcion
    
     public static double LeerDouble(String mensaje)
    {
     double num=0;   
     do{
            try{
            num=Double.parseDouble(JOptionPane.showInputDialog(mensaje));
            if(num<=0)
                JOptionPane.showMessageDialog(null,"Debe ingresar números positivos");
            }catch(Exception e)
            {
                 JOptionPane.showMessageDialog(null,"Error NO debe digitar letras");
            }
            
            }while(num<=0);
     return num;
    }//fin de leer real
    
     public static int LeerInt(String mensaje)
    {
     int num=0;   
     do{
            try{
            num=Integer.parseInt(JOptionPane.showInputDialog(mensaje));
            if(num<=0)
                JOptionPane.showMessageDialog(null,"Debe ingresar números positivos");
            }catch(Exception e)
            {
                 JOptionPane.showMessageDialog(null,"Error NO debe digitar letras");
            }
            
            }while(num<=0);
     return num;
    }//fin de leer real
    
    public static String LeerString(String mensaje)
    {
     String texto="";   
     do{
            try{
            texto=JOptionPane.showInputDialog(mensaje);
            if(texto.equals(""))
                JOptionPane.showMessageDialog(null,"Debe ingresar informacion");
            }catch(Exception e)
            {
                 JOptionPane.showMessageDialog(null,"Error "+e);
            }
            
            }while(texto.equals(""));
     return texto;
    }//fin de leer opcion
    
    
    public static String LeerDia()
    {
        //lectura de dias, tambien se puede hacer de otra forma
        Object opciones;//las opciones del selector deben ser tipo object
        //se crea un vector tipo object que llamé dias con las opciones que necesito
        Object[]dias={"lunes","martes","miércoles","jueves","viernes","sábado","domingo"};
        do{//este ciclo esta validando cuando seleccionan el boton cancel... sino se coloca el cancel se sale abruptamente del programa
            opciones=JOptionPane.showInputDialog(null,"Día: ","Seleccione una opción ",JOptionPane.QUESTION_MESSAGE,null,dias,dias[0]);
            //se pide la variable opciones para pasarlo a dias que es string, se selecciona solo una de las que queremos
        }while(opciones==null);//validando el CANCEL, si alguno sabe quitarlo de la ventana nos muestra!!!
        String dia=opciones.toString();//pasamos la opcion tipo Object a string
        return dia;
    }//fin leer dia
    
     //Método para validar una fecha escrita por el usuario formato (AAAA-MM-DD)
    public static LocalDate LeerFecha(String mensaje) 
    {    
        LocalDate fecha = null;    
        DateTimeFormatter formatoFec = DateTimeFormatter.ofPattern("dd/MM/yyyy");    
        do {        
            try {            
            String input = JOptionPane.showInputDialog(mensaje);
            //Se convierte el string en Local Date            
            fecha = LocalDate.parse(input, formatoFec);        
            } 
            catch (DateTimeParseException e) 
            {            
            JOptionPane.showMessageDialog(null, "Formato de fecha inválido. Use el formato dd-MM-yyyy");     
            }    
        } while (fecha == null);    
        return fecha;
    }//fin leer fecha


}//fin clase validaciones


