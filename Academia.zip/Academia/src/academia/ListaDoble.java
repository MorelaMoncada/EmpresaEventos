package academia;;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;

public class ListaDoble 
{
    //atributos propios y privados
    private Nodo Start, End;

    
    //apuntadores auxiliares, q para cualquier metodo y p SOLO para buscar
    Nodo q,p;
    
    //constructor vacio con condiciones iniciales de lista doble
    public ListaDoble() 
    {
        Start=null;
        End=null;
    }
    
     /*metodo para validar si la lista esta vacia 
    o tiene datos, retorna verdadero si no hay datos*/
    public boolean IsEmpty()
    {
        if(Start==null)
            return true;
        else
            return false;
    }//fin de IsEmpty
    
    /*este metodo crea la lista en caso de que no exista y coloca
    nuevos datos por el apuntador Start, quedando de ultimo el primero
    que ingresa*/
    public void CrearPorInicio(Object d)
    {
        if(IsEmpty()==true)//si esta vacia la lista
        {
            setStart(new Nodo(null,d,null));//pedimos memoria para el primer nodo
            setEnd(getStart());//colocamos el apuntador end en el mismo nodo
        }
        else//ya hay algun dato en la lista
        {
            getStart().setAnt(new Nodo(null,d,getStart()));//se enlaza el nuevo nodo con el anterior de start
            setStart(getStart().getAnt());//se mueve al apuntador Start para el nuevo nodo
        }//fin si
        
    }//fin de crear por inicio

    /*este metodo crea la lista en caso de que no exista y coloca
    nuevos datos por el apuntador End, quedando el primero
    que ingresa de primero y los demas por el final*/
    public void CrearPorFinal(Object d)
    {
        if(IsEmpty()==true)//si esta vacia la lista
        {
            setStart(new Nodo(null,d,null));//pedimos memoria para el primer nodo
            setEnd(getStart());//colocamos el apuntador end en el mismo nodo
        }
        else//ya hay algun dato en la lista
        {
            getEnd().setSig(new Nodo(getEnd(),d,null));//se enlaza el nuevo nodo con el siguiente del ultimo
            setEnd(getEnd().getSig());//se mueve al apuntador End para el nuevo nodo
        }//fin si
        
    }//fin de crear por final
    
    /*metodo que retorna una cadena con los datos de la lista NO imprime*/
    public String ConcatenarDesdeStart()
    {
        String Texto="";//para el retorno
        if(IsEmpty()==false)//si existen datos en la lista
        {
            //colocamos el apuntador auxiliar en el primer nodo
            q=getStart();
            while(q!=null)//mientras q este apuntando algun dato alojado en el nodo
            {
                Texto=Texto+q.toString()+"\n";
                q=q.getSig();//adelantamos en la lista para que salga del ciclo
            }//fin mientras
        }//fin si
        return Texto;
    }//fin de imprimir desde inicio
    
      /*metodo que retorna una cadena con los datos de la lista NO imprime*/
    public String ConcatenarDesdeEnd()
    {
        String Texto="";//para el retorno
        if(IsEmpty()==false)//si existen datos en la lista
        {
            //colocamos el apuntador auxiliar en el ultimo nodo
            q=getEnd();
            while(q!=null)//mientras q este apuntando algun dato alojado en el nodo
            {
                Texto=Texto+q.toString()+"\n";
                q=q.getAnt();//retrocedemos en la lista para que salga del ciclo
            }//fin mientras
        }//fin si
        return Texto;
    }//fin de imprimir desde end
    
    
    /*busca por id un cursoy si lo encuentra retorna verdadero y deja ubicado en el dato 
    al nodo p ....y si no lo encuentra retorna falso y p no apunta a nada*/
     public boolean Buscar(String id)
        {
            String aux;
            p=getStart();//se comienza desde el primer dato
            aux=((Cursos)(p.getDato())).getIdCurso();//se toma solo el id de curso
            while(p!=null&&!(aux.equals(id)))//se sale por p=null no lo encuentra o por que se encuentra el dato
            {
                p=p.getSig();//se adelanta en la lista
                if(p!=null)//si hay datos que asignar a aux
                    aux=((Cursos)(p.getDato())).getIdCurso();
                    
            }//fin mientras
            if(p==null)//no lo encuentra
                return false;
            else//queda ubicado p en el dato
                return true;
      }//fin de buscar
        
   
     
/*este metodo retorna un entero con el numero de datos que estan
     alojados en la lista*/     
public int ContarNodos()
    {
        int con=0;
        if(IsEmpty()==false)//hay datos
        {
            q=getStart();
            while(q!=null)
            {
                con=con+1;
                q=q.getSig();
            }//fin mientras
        }//fin si
        
        return con;
        
    }     //fin de contar nodos

public void InsertarStart(Object info)
{
if(IsEmpty()==false)//si hay datos
{
 /*se crea el nuevo nodo y se enlaza en sig con start y en ant se coloca null porque 
   quedara de primero y todo el nodo se enlaza con el ant de start*/
      getStart().setAnt(new Nodo(null,info,getStart()));
      setStart(getStart().getAnt());//se pasa a Start para el nuevo nodo
}//fin si

} //fin insertar start	

public void InsertarEnd(Object info)
{
if (IsEmpty()==false)//si hay datos
{
/*se crea el nuevo nodo y se enlaza en ant con End y en sig se coloca null porque 
   quedara de ultimo y todo el nodo se enlaza con el sig de End*/
    getEnd().setSig(new Nodo(getEnd(),info,null));
    setEnd(getEnd().getSig());//se pasa a End para el nuevo nodo
} //fin si
} //fin de insertar end

/*este metodo recibe un id referencia para buscar e insertar antes un nuevo
dato, y recibe info que es todo el dato para insertar antes de id*/
public void InsertarAntes(String idRef, Object info)
{
if(IsEmpty()==false)//si hay datos
{
	if(Buscar(idRef)==false)//si el id referencia NO se encuentra en la lista
                    JOptionPane.showMessageDialog(null,"el dato referencia no se encuentra en la lista");
        else{//si el id referencia SI se encuentra en la lista queda p apuntandole
            if(p==getStart())//si el dato referencia esta de primero
            	InsertarStart(info);//se llama al metodo de insertar de primero
            else{//dato referencia NO esta de primero
		p.setAnt(new Nodo(p.getAnt(),info,p));
		p.getAnt().getAnt().setSig(p.getAnt());
                
                //tambien esta otra forma funciona
                // p.getAnt().setSig (new Nodo(p.getAnt(),info,p));
                //p.setAnt(p.getAnt().getSig());
    	    }//fin si 
           }//fin si 
}//fin si
}//fin de insertar antes
/*p.getAnt().setSig (new Nodo(p.getAnt(),info,p));
p.setAnt(p.getAnt().getSig());*/


/*este metodo recibe un id referencia para buscar e insertar despues un nuevo
dato, y recibe info que es todo el dato para insertar despues de id*/
public void InsertarDespues(String idRef, Object info)
    {
         if(IsEmpty()==false)//si hay datos
         {
             if(Buscar(idRef)==false)
                 JOptionPane.showMessageDialog(null,"el dato referencia no se encuentra en la lista");
             else{
                 if(p==getEnd())
                    InsertarEnd(info);
                 else{  
                      p.setSig(new Nodo(p,info,p.getSig()));
                      p.getSig().getSig().setAnt(p.getSig());
                 }//fin si
                        
                }//fin si
          }//fin si
      
}//fin de insertar despues



/*este metodo elimina el primer dato de la lista
y lo retorna para que sepan que dato se elimina*/
public Object LiberarStart()
{
Object info= "";//dato para el retorno
if(IsEmpty()== false)//hay datos
{
   info= getStart().getDato();//se almacena el primer dato
   if ((getStart().getSig()) == null)//hay un solo dato en la lista
   {
    getStart().finalize();
    getEnd().finalize();
    Start=End=null;//datos iniciales del constructor de lista vacia
   }
   else{//hay varios datos
    setStart(getStart().getSig());//se pasa el apuntador Start para el siguiente
    getStart().getAnt().finalize();//se llama al destructor por ant
    getStart().setAnt(null);//se cambia ant por null porque ya queda de primero	
    }//fin si
 } //fin nsi        
return info;
}//fin liberarStart

/*este metodo elimina el ultimo dato de la lista
y lo retorna para que sepan que dato se elimina*/
public Object LiberarEnd()
{
Object info= "";//dato para el retorno
if(IsEmpty() == false)//hay datos
{
info= getEnd().getDato();//se almacena el primer dato
if((getStart().getSig()) == null)//hay un solo dato en la lista
{
   getStart().finalize();
   getEnd().finalize();
   Start=End=null;//datos iniciales del constructor de lista vacia
}
else
{//hay varios datos
    setEnd(getEnd().getAnt());//se pasa el apuntador End para el anterior
    getEnd().getSig().finalize();//se llama al destructor por sig
    getEnd().setSig(null);//se cambia sig por null porque ya queda de ultimo
}
}                            
 return info;
}// liberarEnd

/*este metodo recibe el id del dato a eliminar y en el lugar donde se
encuentre lo elimina y libera la memoria*/
public void LiberarDato(String Idc)
{
 if(IsEmpty() == false)//hay datos
 {
    if(Buscar(Idc) == true)//se encuentra el id a liberar
    {
      if(p==getStart())//esta de primero el dato para eliminar?
         LiberarStart();//se invoca al metodo para eliminar el primero
      else
      {//no esta de primero
          if(p==getEnd())//esta de ultimo el daro para eliminar?
               LiberarEnd();//se invoca al metodo para eliminar el ultimo
          else{//esta entre dos y p esta ubicado
               p.getSig().setAnt(p.getAnt());//se enlazan los dos nodos alrededor de p
               p.getAnt().setSig(p.getSig());
               p.finalize();//se libera p
               }
      }
          JOptionPane.showMessageDialog(null,"Se elimó el curso exitosamente");
    }
    else
       JOptionPane.showMessageDialog(null,"no se encontró el curso en la lista");
    //fin si
 }//fin si
              
}//fin de liberarDato

/*metodo que recibe un id y actualiza sus datos en caso de que se encuentre*/
public void Actualizar(String idc)
{
int op;
if(IsEmpty()==false)//hay datos
{
    if(Buscar(idc)==false)//si el dato no se encuentra
	JOptionPane.showMessageDialog(null,"el dato para actualizar No esta en la lista");
    else//si el dato se encuentra
    {
    //se inicializan las variables auxiliares para mostrar los datos y permitir los cambios
    String Nom=((Cursos)p.getDato()).getNombre(), Hor=((Cursos)p.getDato()).getHorario(), Au=((Cursos)p.getDato()).getAula(), Di=((Cursos)p.getDato()).getDia();
    int Cup= ((Cursos)p.getDato()).getCupos(),Dispo= ((Cursos)p.getDato()).getDisponibilidad();
    LocalDate FechaI= ((Cursos)p.getDato()).getFechaIni(), FechaF= ((Cursos)p.getDato()).getFechaFin();
    /*se da el formato establecido La clase DateTimeFormatter es parte del paquete java.time.format 
      y se utiliza para formatear y analizar objetos de fecha y hora 
      el ofPattern Crea un formateador utilizando el patrón y la configuración regional especificados*/    
        DateTimeFormatter formatoFec = DateTimeFormatter.ofPattern("dd/MM/yyyy"); 
      //se pasa el String a LocalDate que es el tipo de fecha sin hora   
       
    do{//se muestran todos los atributos en menu para el cambio o la actualizacion
        op=Integer.parseInt(JOptionPane.showInputDialog("Actualizar Dato\n"
                + "\n1. Nombre "+Nom           
                + "\n2. Horario "+Hor 
                + "\n3. Aula "+Au
                + "\n4. Día "+Di
                + "\n5. Cupos"+Cup
                + "\n6. Disponibilidad "+Dispo
                + "\n7. Fecha Inicio "+FechaI
                + "\n8. Fecha final "+FechaF
                + "\n9.	Terminar")); 
 	switch(op)//En caso de (op)
        {//de acuerdo al caso se cambia el atributo deseado pero la auxiliar
		case 1: Nom=JOptionPane.showInputDialog("Nuevo nombre: ");
                        break;   
		case 2: Hor=JOptionPane.showInputDialog("Nuevo horario: ");
                        break;
		case 3: Au=JOptionPane.showInputDialog("Nueva aula: ");
                        break;
		case 4: Di=JOptionPane.showInputDialog("Nuevo día: ");
                        break;
		case 5: Cup=Integer.parseInt(JOptionPane.showInputDialog("Nuevos cupos: "));
                        break;
		case 6: Dispo=Integer.parseInt(JOptionPane.showInputDialog("Nuevo nombre: "));
                        break;
                case 7: FechaI= LocalDate.parse(JOptionPane.showInputDialog("nueva Fecha de inicio de curso: dd/MM/yyyy"),formatoFec);
                        break;
                case 8: FechaF=LocalDate.parse(JOptionPane.showInputDialog("nueva Fecha de final de curso: dd/MM/yyyy"),formatoFec);
                        break;
        }//Fin caso
    }while(op<9);//fin mientras
        int resp;//respuesta para grabar los cambios
        resp=JOptionPane.showConfirmDialog(null,"desea grabar los cambios en el curso :"
                +idc,"Actualizando",JOptionPane.YES_NO_OPTION);
        if (resp==JOptionPane.YES_OPTION)//si desea grabar los cambios
        {
        ((Cursos)p.getDato()).setNombre(Nom); 
        ((Cursos)p.getDato()).setHorario(Hor);
        ((Cursos)p.getDato()).setAula(Au);
        ((Cursos)p.getDato()).setDia(Di);
        ((Cursos)p.getDato()).setCupos(Cup);
        ((Cursos)p.getDato()).setDisponibilidad(Dispo);
        ((Cursos)p.getDato()).setFechaIni(FechaI);
        ((Cursos)p.getDato()).setFechaFin(FechaF);
        JOptionPane.showMessageDialog(null,"se actualizaron los datos");
        }
        else
            JOptionPane.showMessageDialog(null,"los cambios NO se actualizaron");
        //fin si
    }//fin si
}//fin si
}//fin actualizar






    public Nodo getStart() {
        return Start;
    }

    public void setStart(Nodo Start) {
        this.Start = Start;
    }

    public Nodo getEnd() {
        return End;
    }

    public void setEnd(Nodo End) {
        this.End = End;
    }

    
    
}//fin clase lista doble
