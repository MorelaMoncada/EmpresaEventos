
package academia;

import javax.swing.JOptionPane;

public class Academia {

 
    public static void main(String[] args) 
    {
        //instanciar las clases
        Academia objAca=new Academia();
        Archivos objArc=new Archivos();
        CRUDCursos objCRUDC=new CRUDCursos();
        ManejoMatriz objManMat=new ManejoMatriz();
        ListaSimple objLS=new ListaSimple();
        ListaDoble objLD=new ListaDoble();
        ManejoListas objML=new ManejoListas();
        Matriz objMat=new Matriz();
        
        String idc,idr;
        int maxf=-1, maxc=-1;
        Object mat[][]=null;
        String texto;
        int op=0,op1,op2,op3,op4,opCrear,resp;
        Cursos objC=new Cursos();//para lecturas de cursos
        do{//ciclo del menu principal
           op=Validaciones.LeerOpcion(objAca.MenuPpal(),5);//invocamos el metodo de validacion hasta 5
           switch(op)//en caso de op
            {
                case 1:do{//ciclo del menu de archivo curso
                          op1=Validaciones.LeerOpcion(objAca.MenuManejoArchivoCursos(),4); 
                          switch(op1)//en caso de op1
                          {
                              case 1: idc=Validaciones.LeerString("Codigo o id del curso: ");
                                      objCRUDC.IngresarCurso(objArc, idc);
                                      break;
                              case 2: JOptionPane.showMessageDialog(null,"El archivo de cursos es: \n"+objCRUDC.MostrarTodo(objArc));
                                      break;
                          }//fin caso del menu de archivo de cursos
                         }while(op1<4);//fin mientras del menu de archivo curso
                       break;
                case 2:do{//ciclo del menu de matriz curso
                          op2=Validaciones.LeerOpcion(objAca.MenuManejoMatrizCursos(),20); 
                          switch(op2)//en caso de op2
                          {
                              case 1: resp=JOptionPane.showConfirmDialog(null,"Desea usar los datos de la prueba?","Ingresar Datos",JOptionPane.YES_NO_OPTION);
                                      if(resp==JOptionPane.YES_OPTION)
                                      {
                                          maxf=3;
                                          maxc=3;
                                          mat=objMat.CrearMatriz(maxf, maxc);
                                          mat=objManMat.PruebaEscritorio(mat);
                                      }
                                      else
                                      {
                                      maxf=Validaciones.LeerInt("Digite número de filas: ");
                                      maxc=Validaciones.LeerInt("Digite número de columnas: ");
                                      mat=objMat.CrearMatriz(maxf, maxc);
                                      mat=objManMat.LlenarMatriz(mat, maxf, maxc);
                                      }
                                      break;
                              case 2: if(objMat.MatrizVerificar(mat)==false)
                                           JOptionPane.showMessageDialog(null,"la matriz por filas es\n"+objMat.JuntarMatrizFilas(mat));
                                      else
                                           JOptionPane.showMessageDialog(null,"La matriz esta vacia");
                                      break;
                              case 3: if(objMat.MatrizVerificar(mat)==false)
                                           JOptionPane.showMessageDialog(null,"la matriz por columnas es\n"+objMat.JuntarMatrizColumnas(mat));
                                      else
                                           JOptionPane.showMessageDialog(null,"La matriz esta vacia");
                                      break; 
                              case 4: if(objMat.MatrizVerificar(mat)==false)
                                      {
                                      texto=objManMat.BuscarDisponibles(mat, maxf, maxc);
                                      if(texto.equals(""))
                                          JOptionPane.showMessageDialog(null,"NO hay cursos con disponibilidad");
                                      else
                                          JOptionPane.showMessageDialog(null,"los cursos con disponibilidad son:\n"+texto);
                                      //fin si
                                      }
                                      else
                                           JOptionPane.showMessageDialog(null,"La matriz esta vacia");
                                      break;
                              case 5 :if(objMat.MatrizVerificar(mat)==false)
                                      { 
                                        texto = objManMat.BuscarCuposMayor40(mat, maxf, maxc);
                                        if(texto.equalsIgnoreCase(""))
                                            JOptionPane.showMessageDialog(null, "No hay cursos con mas de 40 cupos");
                                        else
                                            JOptionPane.showMessageDialog(null, "Los cursos con mas de 40 cupos son:\n"+texto);
                                        //fin si
                                      }
                                      else
                                           JOptionPane.showMessageDialog(null,"La matriz esta vacia");
                                      break;
                               case 6 :if(objMat.MatrizVerificar(mat)==false)
                                      { 
                                       texto = objManMat.ConcatenarDiagPrin(mat, maxf, maxc);
                                        if(texto.equalsIgnoreCase(""))
                                            JOptionPane.showMessageDialog(null, "La matriz esta vacia");
                                        else
                                            JOptionPane.showMessageDialog(null, "La diagonal principal es:\n"+texto);
                                      }
                                      else
                                           JOptionPane.showMessageDialog(null,"La matriz esta vacia");
                                      break;
                               case 7 : if(objMat.MatrizVerificar(mat)==false)
                                       { 
                                            texto = objManMat.ConcatenarDiagSecun(mat, maxf, maxc);
                                             if(texto.equalsIgnoreCase(""))
                                                 JOptionPane.showMessageDialog(null, "La matriz esta vacia");
                                             else
                                                 JOptionPane.showMessageDialog(null, "La diagonal secundaria es:\n"+texto);
                                       }
                                      else
                                           JOptionPane.showMessageDialog(null,"La matriz esta vacia");
                                      break;
                                case 8:if(objMat.MatrizVerificar(mat)==false)
                                       { 
                                       objManMat.CopiarMatrizAlArchivo(mat, maxf, maxc, objArc, objCRUDC);
                                       }
                                       else
                                           JOptionPane.showMessageDialog(null,"La matriz esta vacia");
                                       break;
                                case 9:if(objMat.MatrizVerificar(mat)==false)
                                       { 
                                       objManMat.CopiarMatrizAlArchivoSinDisponibilidad(mat, maxf, maxc, objArc, objCRUDC);
                                       }
                                       else
                                           JOptionPane.showMessageDialog(null,"La matriz esta vacia");
                                       break; 
                                case 10:if(objMat.MatrizVerificar(mat)==false)
                                       { 
                                        texto=objManMat.JuntarCursosArchivoNoEstenEnMatriz(mat, maxf, maxc, objArc, objCRUDC);
                                        if(texto.equalsIgnoreCase(""))
                                            JOptionPane.showMessageDialog(null, "No hay cursos del archivo que no esten en matriz");
                                        else
                                             JOptionPane.showMessageDialog(null, "Los cursos que estan en archivo y NO estan en la matriz son: \n"+texto);
                                        }
                                        else
                                           JOptionPane.showMessageDialog(null,"La matriz esta vacia");
                                        break;
                                 case 11:if(objMat.MatrizVerificar(mat)==false)
                                       { 
                                           if(maxc<2)
                                               JOptionPane.showMessageDialog(null,"La matriz tiene un solo data en cada fila, NO se organiza");
                                           else{
                                                    mat=objManMat.organizarPorIdPorFilas(mat, maxf, maxc);
                                                    JOptionPane.showMessageDialog(null,"se organizaron las filas de La matriz");
                                               }
                                       }
                                       else
                                           JOptionPane.showMessageDialog(null,"La matriz esta vacia");
                                       break;         
                          }//fin caso del menu de matriz de cursos
                         }while(op2<20);//fin mientras del menu de matriz curso
                       break;   
            case 3:do{//ciclo del menu de lista simple de curso
                          op3=Validaciones.LeerOpcion(objAca.MenuManejoListaSimpleCursos(),20); 
                          switch(op3)//en caso de op3
                          {
                              case 1: objLS=new ListaSimple();
                                      opCrear=Validaciones.LeerOpcion("Crear la lista: \n1. Por Inicio (el dato que llega queda siempre de primero)"
                                      + "                                                                   \n2. Por Final (el dato que llega queda siempre de último)",2);
                                      objLS=objML.Crear(objLS, opCrear);
                                      break;
                              case 2: if(objLS.IsEmpty()==true)
                                         JOptionPane.showMessageDialog(null,"La lista esta vacia");
                                      else
                                         JOptionPane.showMessageDialog(null,"El contenido de la lista es:\n"+objLS.ConcatenarDesdeInicio());
                                      //fin si
                                      break;
                              case 3: if(objLS.IsEmpty()==true)
                                         JOptionPane.showMessageDialog(null,"La lista esta vacia");
                                      else 
                                         {
                                          idc=Validaciones.LeerString("Codigo o id del curso para ingresar de primero: ");   
                                          objC=objC.IngresarDatos(idc);
                                          objLS.InsertarStart(objC);
                                          JOptionPane.showMessageDialog(null,"El curso: "+idc+" fue insertado de primero en la lista");
                                         }
                                     break; 
                              case 4: if(objLS.IsEmpty()==true)
                                         JOptionPane.showMessageDialog(null,"La lista esta vacia");
                                      else 
                                         {
                                          idc=Validaciones.LeerString("Codigo o id del curso para ingresar de último: ");   
                                          objC=objC.IngresarDatos(idc);
                                          objLS.InsertarEnd(objC);
                                          JOptionPane.showMessageDialog(null,"El curso: "+idc+" fue insertado de último en la lista");
                                         }
                                     break; 
                              case 5: if(objLS.IsEmpty()==true)
                                         JOptionPane.showMessageDialog(null,"La lista esta vacia");
                                      else 
                                         {
                                          idc=Validaciones.LeerString("Codigo o id del curso para consultar: ");   
                                          objC=(Cursos)objML.ConsultarCurso(objLS, idc);
                                          if(objC==null)
                                              JOptionPane.showMessageDialog(null,"El curso: "+idc+" NO se encuentra en la lista");
                                          else
                                              JOptionPane.showMessageDialog(null,"Los datos del curso: \n"+objC.toString());
                                         }
                                     break;       
                              case 6: if(objLS.IsEmpty()==true)
                                         JOptionPane.showMessageDialog(null,"La lista esta vacia");
                                      else 
                                         {
                                          idr=Validaciones.LeerString("Codigo o id del curso como referencia para insertar antes de el: ");   
                                          if(objLS.Buscar(idr)==true)//por ahora
                                          {
                                              idc=Validaciones.LeerString("Codigo o id del curso a insertar antes: ");
                                              objC=objC.IngresarDatos(idc);
                                              objLS.InsertarAntes(idr, objC);
                                              JOptionPane.showMessageDialog(null,"Se insertó el dato antes de "+idr);
                                          }
                                          else
                                              JOptionPane.showMessageDialog(null,"El dato referencia NO existe en la lista NO se insertó");
                                         }//fin si
                                         break; 
                               case 7: if(objLS.IsEmpty()==true)
                                         JOptionPane.showMessageDialog(null,"La lista esta vacia");
                                      else 
                                         {
                                          idr=Validaciones.LeerString("Codigo o id del curso como referencia para insertar despues de el: ");   
                                          if(objLS.Buscar(idr)==true)//por ahora
                                          {
                                              idc=Validaciones.LeerString("Codigo o id del curso a insertar despues");
                                              objC=objC.IngresarDatos(idc);
                                              objLS.InsertarDespues(idr, objC);
                                              JOptionPane.showMessageDialog(null,"Se insertó el dato despues de "+idr);
                                          }
                                          else
                                              JOptionPane.showMessageDialog(null,"El dato referencia NO existe en la lista NO se insertó");
                                         }//fin si
                                         break; 
                                         
                                case 8: if(objLS.IsEmpty()==true)
                                         JOptionPane.showMessageDialog(null,"La lista esta vacia");
                                        else 
                                         { 
                                             JOptionPane.showMessageDialog(null,"El dato eliminado al inicio fue: "+objLS.LiberarStart());
                                         } 
                                         break; 
                                case 9: if(objLS.IsEmpty()==true)
                                         JOptionPane.showMessageDialog(null,"La lista esta vacia");
                                        else 
                                         { 
                                             JOptionPane.showMessageDialog(null,"El dato eliminado al final fue: "+objLS.LiberarEnd());
                                         } 
                                         break;
                                case 10: if(objLS.IsEmpty()==true)
                                         JOptionPane.showMessageDialog(null,"La lista esta vacia");
                                        else 
                                         { 
                                             idc=Validaciones.LeerString("Ingrese el id de curso a eliminar de la lista: ");
                                             objLS.LiberarDato(idc);
                                         } 
                                         break;          
                               case 11: objLS=objML.ArchivoParaLista(objArc, objLS);
                                        JOptionPane.showMessageDialog(null,"El archivo se paso a la lista");
                                        break;  
                          }//fin caso del menu de lista simple cursos
                       }while(op3<20);//fin mientras del menu de lista simple curso
                       break;           
             case 4:do{//ciclo del menu de lista doble de curso
                          op4=Validaciones.LeerOpcion(objAca.MenuManejoListaDobleCursos(),20); 
                          switch(op4)//en caso de op4
                          {
                              case 1: objLD=new ListaDoble();
                                      opCrear=Validaciones.LeerOpcion("Crear la lista: \n1. Por Inicio (el dato que llega queda siempre de primero)"
                                      + "                                                                   \n2. Por Final (el dato que llega queda siempre de último)",2);
                                      objLD=objML.Crear(objLD, opCrear);
                                      break;
                              case 2: if(objLD.IsEmpty()==true)
                                         JOptionPane.showMessageDialog(null,"La lista esta vacia");
                                      else
                                         JOptionPane.showMessageDialog(null,"El contenido de la lista desde el inicio es:\n"+objLD.ConcatenarDesdeStart());
                                      //fin si
                                      break;
                              case 3: if(objLD.IsEmpty()==true)
                                         JOptionPane.showMessageDialog(null,"La lista esta vacia");
                                      else
                                         JOptionPane.showMessageDialog(null,"El contenido de la lista desde el final es:\n"+objLD.ConcatenarDesdeEnd());
                                      //fin si
                                      break;        
                             case 4: if(objLD.IsEmpty()==true)
                                         JOptionPane.showMessageDialog(null,"La lista esta vacia");
                                      else 
                                         {
                                          idc=Validaciones.LeerString("Codigo o id del curso para ingresar de primero: ");   
                                          objC=objC.IngresarDatos(idc);
                                          objLD.InsertarStart(objC);
                                          JOptionPane.showMessageDialog(null,"El curso: "+idc+" fue insertado de primero en la lista");
                                         }
                                     break; 
                              case 5: if(objLD.IsEmpty()==true)
                                         JOptionPane.showMessageDialog(null,"La lista esta vacia");
                                      else 
                                         {
                                          idc=Validaciones.LeerString("Codigo o id del curso para ingresar de último: ");   
                                          objC=objC.IngresarDatos(idc);
                                          objLD.InsertarEnd(objC);
                                          JOptionPane.showMessageDialog(null,"El curso: "+idc+" fue insertado de último en la lista");
                                         }
                                     break; 
                              case 6: if(objLD.IsEmpty()==true)
                                         JOptionPane.showMessageDialog(null,"La lista esta vacia");
                                      else 
                                         {
                                          idc=Validaciones.LeerString("Codigo o id del curso para consultar: ");   
                                          objC=(Cursos)objML.ConsultarCurso(objLD, idc);
                                          if(objC==null)
                                              JOptionPane.showMessageDialog(null,"El curso: "+idc+" NO se encuentra en la lista");
                                          else
                                              JOptionPane.showMessageDialog(null,"Los datos del curso: \n"+objC.toString());
                                         }
                                     break;       
                              case 7: if(objLD.IsEmpty()==true)
                                         JOptionPane.showMessageDialog(null,"La lista esta vacia");
                                      else 
                                         {
                                          idr=Validaciones.LeerString("Codigo o id del curso como referencia para insertar antes de el: ");   
                                          if(objLD.Buscar(idr)==true)//por ahora
                                          {
                                              idc=Validaciones.LeerString("Codigo o id del curso a insertar antes: ");
                                              objC=objC.IngresarDatos(idc);
                                              objLD.InsertarAntes(idr, objC);
                                              JOptionPane.showMessageDialog(null,"Se insertó el dato antes de "+idr);
                                          }
                                          else
                                              JOptionPane.showMessageDialog(null,"El dato referencia NO existe en la lista NO se insertó");
                                         }//fin si
                                         break; 
                               case 8: if(objLD.IsEmpty()==true)
                                         JOptionPane.showMessageDialog(null,"La lista esta vacia");
                                      else 
                                         {
                                          idr=Validaciones.LeerString("Codigo o id del curso como referencia para insertar despues de el: ");   
                                          if(objLD.Buscar(idr)==true)//por ahora
                                          {
                                              idc=Validaciones.LeerString("Codigo o id del curso a insertar despues");
                                              objC=objC.IngresarDatos(idc);
                                              objLD.InsertarDespues(idr, objC);
                                              JOptionPane.showMessageDialog(null,"Se insertó el dato despues de "+idr);
                                          }
                                          else
                                              JOptionPane.showMessageDialog(null,"El dato referencia NO existe en la lista NO se insertó");
                                         }//fin si
                                         break; 
                                         
                                case 9: if(objLD.IsEmpty()==true)
                                         JOptionPane.showMessageDialog(null,"La lista esta vacia");
                                        else 
                                         { 
                                             JOptionPane.showMessageDialog(null,"El dato eliminado al inicio fue: "+objLD.LiberarStart());
                                         } 
                                         break; 
                                case 10: if(objLD.IsEmpty()==true)
                                         JOptionPane.showMessageDialog(null,"La lista esta vacia");
                                        else 
                                         { 
                                             JOptionPane.showMessageDialog(null,"El dato eliminado al final fue: "+objLD.LiberarEnd());
                                         } 
                                         break;
                                case 11: if(objLD.IsEmpty()==true)
                                         JOptionPane.showMessageDialog(null,"La lista esta vacia");
                                        else 
                                         { 
                                             idc=Validaciones.LeerString("Ingrese el id de curso a eliminar de la lista: ");
                                             objLD.LiberarDato(idc);
                                         } 
                                         break;          
                               case 12: objLD=objML.ArchivoParaLista(objArc, objLD);
                                        JOptionPane.showMessageDialog(null,"El archivo se paso a la lista");
                                        break; 
                               case 13:if(objLD.IsEmpty()==true)
                                         JOptionPane.showMessageDialog(null,"La lista esta vacia");
                                        else 
                                         { 
                                             idc=Validaciones.LeerString("Ingrese el id de curso a modificar en la lista: ");
                                             objLD.Actualizar(idc);
                                         } 
                                         break;    
                               case 14:if(objLD.IsEmpty()==true)
                                         JOptionPane.showMessageDialog(null,"La lista esta vacia");
                                        else 
                                         { 
                                             if(objLD.getStart().getSig()==null)
                                                 JOptionPane.showMessageDialog(null,"La lista solo tiene un dato NO se organiza");
                                             else{
                                             objLD=objML.OrganizarAscendentePorId(objLD);
                                             JOptionPane.showMessageDialog(null,"La lista fue organizada");
                                             }
                                         } 
                                         break;                
                          }//fin caso del menu de lista doble cursos
                       }while(op4<20);//fin mientras del menu de lista doble curso
                       break;           
                                  
                       
            }//fin caso del menu principal
          }while(op<5);//fin mientras del menu principal
      
    }//fin del main
    
    public String MenuPpal()
    {
        return "MENU PRINCIPAL\n"
                + "1. Manejo de Archivo de Cursos\n"
                + "2. Manejo de Matriz de cursos\n"
                + "3. Manejo de Lista Simple de cursos\n"
                + "4. Manejo de Lista Doble de cursos\n"
                + "5. Terminar";
    }
    public String MenuManejoArchivoCursos()
    {
        return "MENU ARCHIVO CURSOS\n"
                + "1. Ingresar un curso\n"
                + "2. Mostrar Todo el archivo\n"
                + "3. Consultar un curso\n"
                + "4. Regresar al menu principal";
    }
    public String MenuManejoMatrizCursos()
    {
        return "MENU MATRIZ DE CURSOS\n"
                + "1. Ingresar datos a la matriz de cursos\n"
                + "2. Mostrar por filas\n"
                + "3. Mostrar por columnas\n"
                + "4. Mostrar cursos disponibles\n"
                + "5. Mostrar cursos con mas de 40 cupos\n"
                + "6. Mostrar diagonal principal\n"
                + "7. Mostrar diagonal secundaria\n"
                + "8. Copiar la matriz al archivo\n"
                + "9. Copiar los cursos sin disponibilidad de la matriz al archivo\n"
                + "10. Mostrar los cursos del archivo que no están en la matriz\n"
                + "11. Organizar las filas por IdCurso\n"
                + "20. Regresar al menu principal";
    }
    public String MenuManejoListaSimpleCursos()
    {
        return "MENU LISTA SIMPLE CURSOS\n"
                + "1. Crear lista de cursos\n"
                + "2. Imprimir lista\n"
                + "3. Insertar Curso al inicio\n"
                + "4. Insertar Curso al final\n"
                + "5. Consultar un Curso específico\n"
                + "6. Insertar un curso antes de un dato referencia\n"
                + "7. Insertar un curso despues de un dato referencia\n"
                + "8. (Liberar) Eliminar el primer dato de la lista\n"
                + "9. (Liberar) Eliminar el ultimo dato de la lista\n"
                + "10. (Liberar) Eliminar un dato deseado\n"
                + "11. Copiar el archivo a la lista\n"
                + "20. Regresar al menu principal";
    }
     public String MenuManejoListaDobleCursos()
    {
        return "MENU LISTA DOBLE CURSOS\n"
                + "1. Crear lista de cursos\n"
                + "2. Imprimir lista desde Start\n"
                + "3. Imprimir lista desde End\n"
                + "4. Insertar Curso al inicio\n"
                + "5. Insertar Curso al final\n"
                + "6. Consultar un Curso específico\n"
                + "7. Insertar un curso antes de un dato referencia\n"
                + "8. Insertar un curso despues de un dato referencia\n"
                + "9. (Liberar) Eliminar el primer dato de la lista\n"
                + "10. (Liberar) Eliminar el ultimo dato de la lista\n"
                + "11. (Liberar) Eliminar un dato deseado\n"
                + "12. Copiar el archivo a la lista\n"
                + "13. Actualizar un dato en la lista\n"
                + "14. Organizar por IdCurso\n"
                + "20. Regresar al menu principal";
    }
}//fin clase academia
