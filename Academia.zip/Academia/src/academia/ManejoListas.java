
package academia;

import java.time.LocalDate;
import javax.swing.JOptionPane;


public class ManejoListas  
{
 /*crear una lista simple, recibe la opcion que le indica si
    va a crear la lista por el inicio o por el final y retorna la
    lista con los datos, es excluyente se debe crear o por inicio
    o por final*/
 public ListaSimple Crear(ListaSimple ls,int op)
 {
    Cursos objCur;//para lista de cursos
    int res;//respuesta del mientras
    String Idc;//para el id de curso
    res=JOptionPane.showConfirmDialog(null,"Ingresar Curso?","Crear lista",JOptionPane.YES_NO_OPTION);
    while(res==JOptionPane.YES_OPTION) //si respuesta es si
    {
        objCur=new Cursos();//para que sobreescriba
        Idc=Validaciones.LeerString("Digite id o codigo del curso: ");  
        objCur=objCur.IngresarDatos(Idc);//dato para ingresar a la lista
        //crear es excluyente
        if(op==1)//crear por inicio
        {
            ls.CrearPorInicio(objCur);//se crea el nodo con el dato por inicio
        }
        else//crear por final
        {
            ls.CrearPorFinal(objCur);//se crea el nodo con el dato por final
        } 
        res=JOptionPane.showConfirmDialog(null,"Ingresar mas Cursos?","Crear lista",JOptionPane.YES_NO_OPTION);
    }//fin mientras
    return ls; 
 }//fin de crear
  
 /*este metodo de acuerdo a un id o codigo retorna el curso en caso de encontrarlo 
 en la lista, si no lo encuentra retorna null*/
 public Object ConsultarCurso(ListaSimple ls, String idc)
 {
    if(ls.Buscar(idc)==true)//se llama al metodo de buscar curso de lista
    {
        return ls.p.getDato();//el buscar deja ubicado a p en el dato que se esta buscando
    }
    return null;//no lo encuentra retorna null
 }//fin de consultar
 
 
  /*metodo que copia todo el contenido del archivo a la lista simple, recibe el archivo y la lista
 y retorna la lista con todos los datos del archivo*/
    
    public ListaSimple ArchivoParaLista(Archivos objArch, ListaSimple Ls) {
      
        try {
            //locales auxiliares para extraer la informacion del archivo
            String code, nom, horario, aula,  dia;
            LocalDate fechIn, fechFn;
            int cupos, disp;
           
            String Reg[];//para tomar la linea String como vector de datos y facilitar el trabajo con el registro
            //se abre el archivo modo lectura y se imprime el mensaje de apertura que retorna
            JOptionPane.showMessageDialog(null, "" + objArch.AbrirArchivoModoLectura("Cursos.txt"));
            //se invoca al metodo de leer registro con 6 atributos para el vector de la linea o registro del archivo plano 
            //se recibe el texto en Reg
            Reg = objArch.LeerRegistro(9);
            //mientras existan datos en el archivo
            while (Reg != null) //mientras not EOF()
            {
               /*los datos del Reg que se obtiene del archivo plano de texto se 
                asignan a las variables auxiliares locales para su facil manejo 
                como posiciones del vector String*/
                code  = Reg[0];
                nom = Reg[1];
                horario = Reg[2];
                aula = Reg[3];
                dia = Reg[4];
                cupos = Integer.parseInt(Reg[5]);
                disp = Integer.parseInt(Reg[6]);
                fechIn = LocalDate.parse(Reg[7]);
                fechFn =LocalDate.parse(Reg[8]);
               
                Cursos objC = new Cursos(code, nom, horario, aula, dia, cupos, disp, fechIn, fechFn);
                Ls.CrearPorFinal(objC);//se copia en la lista por final, NO se llama el insertar porque puede que NO haya lista
                Reg = objArch.LeerRegistro(9);
            }//fin mientras  
            objArch.CerrarArchivoModoLectura();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "***Archivo leído y cerrado correctamente*****");
        }
        return Ls;
     } //FIN MOSTRAR TODO EL ARCHIVO
    
    
    /*--------------------------------------------------------------*/
    
    
    /*crear una lista doble, recibe la opcion que le indica si
    va a crear la lista por el inicio o por el final y retorna la
    lista con los datos, es excluyente se debe crear o por inicio
    o por final*/
 public ListaDoble Crear(ListaDoble ld,int op)
 {
    Cursos objCur;//para lista de cursos
    int res;//respuesta del mientras
    String Idc;//para el id de curso
    res=JOptionPane.showConfirmDialog(null,"Ingresar Curso?","Crear lista",JOptionPane.YES_NO_OPTION);
    while(res==JOptionPane.YES_OPTION) //si respuesta es si
    {
        objCur=new Cursos();//para que sobreescriba
        Idc=Validaciones.LeerString("Digite id o codigo del curso: ");  
        objCur=objCur.IngresarDatos(Idc);//dato para ingresar a la lista
        //crear es excluyente
        if(op==1)//crear por inicio
        {
            ld.CrearPorInicio(objCur);//se crea el nodo con el dato por inicio
        }
        else//crear por final
        {
            ld.CrearPorFinal(objCur);//se crea el nodo con el dato por final
        } 
        res=JOptionPane.showConfirmDialog(null,"Ingresar mas Cursos?","Crear lista",JOptionPane.YES_NO_OPTION);
    }//fin mientras
    return ld; 
 }//fin de crear
  
 /*este metodo de acuerdo a un id o codigo retorna el curso en caso de encontrarlo 
 en la lista, si no lo encuentra retorna null*/
 public Object ConsultarCurso(ListaDoble ld, String idc)
 {
    if(ld.Buscar(idc)==true)//se llama al metodo de buscar curso de lista
    {
        return ld.p.getDato();//el buscar deja ubicado a p en el dato que se esta buscando
    }
    return null;//no lo encuentra retorna null
 }//fin de consultar
 
 
  /*metodo que copia todo el contenido del archivo a la lista doble, recibe el archivo y la lista
 y retorna la lista con todos los datos del archivo*/
    
    public ListaDoble ArchivoParaLista(Archivos objArch, ListaDoble Ld) {
      
        try {
            //locales auxiliares para extraer la informacion del archivo
            String code, nom, horario, aula,  dia;
            LocalDate fechIn, fechFn;
            int cupos, disp;
           
            String Reg[];//para tomar la linea String como vector de datos y facilitar el trabajo con el registro
            //se abre el archivo modo lectura y se imprime el mensaje de apertura que retorna
            JOptionPane.showMessageDialog(null, "" + objArch.AbrirArchivoModoLectura("Cursos.txt"));
            //se invoca al metodo de leer registro con 6 atributos para el vector de la linea o registro del archivo plano 
            //se recibe el texto en Reg
            Reg = objArch.LeerRegistro(9);
            //mientras existan datos en el archivo
            while (Reg != null) //mientras not EOF()
            {
               /*los datos del Reg que se obtiene del archivo plano de texto se 
                asignan a las variables auxiliares locales para su facil manejo 
                como posiciones del vector String*/
                code  = Reg[0];
                nom = Reg[1];
                horario = Reg[2];
                aula = Reg[3];
                dia = Reg[4];
                cupos = Integer.parseInt(Reg[5]);
                disp = Integer.parseInt(Reg[6]);
                fechIn = LocalDate.parse(Reg[7]);
                fechFn =LocalDate.parse(Reg[8]);
               
                Cursos objC = new Cursos(code, nom, horario, aula, dia, cupos, disp, fechIn, fechFn);
                Ld.CrearPorFinal(objC);//se copia en la lista por final, NO se llama el insertar porque puede que NO haya lista
                Reg = objArch.LeerRegistro(9);
            }//fin mientras  
            objArch.CerrarArchivoModoLectura();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "***Archivo leído y cerrado correctamente*****");
        }
        return Ld;
     } //FIN MOSTRAR TODO EL ARCHIVO
    
    
    /*--------------------------------------------------------------*/
    
    //metodo organizar ascendentemente por id en lista doble
    public ListaDoble OrganizarAscendentePorId(ListaDoble objl){
        Nodo t,q;//variables locales
        Object aux;//variable auxiliar para hacer el intercambio
        q=objl.getStart();//se coloca el apuntador q en el primer nodo
        
        while(q!=null){
            t=q.getSig();//se inicializa al apuntador t en el nodo siguiente de q
            while(t!=null){
                if((((Cursos)q.getDato()).getIdCurso().compareTo(((Cursos)t.getDato()).getIdCurso())>0)){
                    //si el id que señala q es mayor que el id que señala t
                    aux=q.getDato();//se guarda el curso que esta señalando q
                    q.setDato(t.getDato());//se cambia el curso que esta señalando t a donde esta q 
                    t.setDato(aux);//se guarda aux en donde esta señalando t
                    }
                t=t.getSig();//se adelanta a t
            }
            q=q.getSig();//se adelanta a q
        }
        return objl;
    }  //fin organizar

    
    
    
    
    
}//fin de manejo listas
