
package academia;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;

public class ManejoMatriz 
{
     //metodo que ingresa los datos totales en la matriz cursos
    public Object [][] LlenarMatriz(Object mat[][], int MaxF, int MaxC)
    {
        int F,C;
        String Idc;
         //objeto curso para el ingreso de datos
        Cursos objcur=new Cursos();
        
    // Si la Matriz No está llena, se puede agregar datos
    //se esta llenando por filas   
    for(F=0;F<=(MaxF-1);F++)
        {
           for(C=0;C<=(MaxC-1);C++)
           {
              Idc=Validaciones.LeerString("Digite id o codigo del curso: ");  
              mat[F][C]=objcur.IngresarDatos(Idc);
           }//Fin para C
        }// Fin para F
  
    return mat;
    }//Fin del Metodo LLenarMatriz
    
    //buscar que cursos tienen disponibilidad en la matriz
    public String BuscarDisponibles(Object mat[][], int MaxF, int MaxC)
    {
    String texto="";//para el retorno
    int i,j;//para los ciclos
    for(i=0;i<=(MaxF-1);i++)
        {
           for(j=0;j<=(MaxC-1);j++)
           {
	 	if (((Cursos)mat[i][j]).getDisponibilidad()!=0)
                {
                        //texto=texto+mat[i][j].toString()+"\n";
		        texto=texto+((Cursos)mat[i][j]).getIdCurso()+" "+((Cursos)mat[i][j]).getNombre();
                }//fin si
           }//fin para j
        }//fin para i
    return texto;
    }//fin buscar disponibles

    //Cuales cursos tienen cupos superiores a 40
    public String BuscarCuposMayor40(Object mat[][], int MaxF, int MaxC){
    String Text="";//variable del retorno
    int i,j;
    for (i=0; i<=(MaxF-1);i++)
    {
        for (j=0; j<=(MaxC-1);j++)
        {
	 	if (((Cursos)mat[i][j]).getCupos() > 40)
                {
		        Text=Text+((Cursos)mat[i][j]).getIdCurso()+" "+((Cursos)mat[i][j]).getNombre();
                }//fin si
        }//fin para j
    }//fin para i
    return Text;
    }//fin buscar cupos mayores
    
    
    /*este metodo retorna la diagonal principal de la matriz en caso de ser cuadrada*/
    public String ConcatenarDiagPrin(Object mat[][], int MaxF, int MaxC){
    String text="";//variable del retorno
    int i;//variable local para el ciclo
    if(MaxF == MaxC){//si es cuadrada
        for(i=0; i<=(MaxF-1); i++)
        {
        text=text+((Cursos)mat[i][i]).getIdCurso()+" "+((Cursos)mat[i][i]).getNombre()+"\n";
        //text=text+mat[i][i].toString()+"\n";
        }//fin para i
    }
    else
        text="Matriz no es cuadrada NO tiene diagonales";
    //fin si
    return text;
}//fin mostrar diagonal principal

     /*este metodo retorna la diagonal secundaria de la matriz en caso de ser cuadrada*/
public String ConcatenarDiagSecun(Object mat[][], int MaxF, int MaxC){
    String text="";//variable de retorno
    int i;
    
    if(MaxF == MaxC){//si es cuadrada
        for(i=0; i<=(MaxF-1); i++)
        {
        //text=text+((Cursos)mat[i][MaxF - 1 - i]).getIdCurso()+((Cursos)mat[i][MaxF - 1 - i]).getNombre();
        text=text+mat[i][MaxF - 1 - i].toString()+"\n";
        }//fin para 
    }else
        text="Matriz no es cuadrada NO tiene diagonales";
    //fin si

    return text;
}

 //4.	Copiar la matriz al archivo
public void CopiarMatrizAlArchivo(Object mat[][], int MaxF, int MaxC, Archivos objArc, CRUDCursos objCRUDC)
{
   int i,j, validar=0;//locales y auxiliares para los ciclos y validar si se grabo algo de la matriz al archivo
for (i=0; i<=(MaxF-1);i++)
    {
        for (j=0; j<=(MaxC-1);j++)
        {
        //si el curso de la matriz no existe en el archivo    
        if(objCRUDC.Buscar(objArc, (((Cursos)mat[i][j]).getIdCurso()))==false)
        {
        	objCRUDC.GrabarCurso(objArc, (Cursos)mat[i][j]);//se graba el curso
        	validar=1;
        }//Fin si
        }//Fin para j
    }//fin para i
if(validar==0) 
      JOptionPane.showMessageDialog(null,"Los datos de la matriz ya estaban en el archivo, no se copió ningún curso al archivo");
else
      JOptionPane.showMessageDialog(null,"algunos datos de la matriz se copiaron en el archivo");
//Fin si
}//Fin copiar matriz al archivo

//5. copiar de la matriz al archivo los cursos que no tienen disponibilidad, tener en cuenta no copiar repetidos
public void CopiarMatrizAlArchivoSinDisponibilidad(Object mat[][],int MaxF, int MaxC, Archivos objArc, CRUDCursos objCRUDC)
{
int i,j, validar=0;
for (i=0; i<=(MaxF-1);i++)
    {
        for (j=0; j<=(MaxC-1);j++)
        {
         if(((Cursos)mat[i][j]).getDisponibilidad()==0)
         {
   	  if(objCRUDC.Buscar(objArc, (((Cursos)mat[i][j]).getIdCurso()))==false)
          {
            objCRUDC.GrabarCurso(objArc, (Cursos)mat[i][j]);
            validar=1;
          }//	fin si
         }//Fin si
        }//    Fin para j
    }//Fin para i
if(validar==0) 
      JOptionPane.showMessageDialog(null,"No hay grupos con disponibilidad en cero o los cursos de la matriz ya estaban en el archivo");
else
      JOptionPane.showMessageDialog(null,"algunos datos de la matriz se copiaron en el archivo");
//Fin si
}//Fin copiar matriz al archivo

//6.	Mostrar los cursos del archivo que no están en la matriz
public boolean Buscar(Object mat[][], int MaxF, int MaxC, String idC)
{
boolean sw=false;
int i,j;
for (i=0; i<=(MaxF-1);i++)
    {
        for (j=0; j<=(MaxC-1);j++)
        {
         if(((Cursos)mat[i][j]).getIdCurso().equalsIgnoreCase(idC))
                sw=true;
         // fin si
        }//fin para j
    }//fin para i
return sw;
}//fin Buscar

public String JuntarCursosArchivoNoEstenEnMatriz(Object mat[][], int MaxF, int MaxC, Archivos objArc, CRUDCursos objCRUDC)
{
String texto = "";//variable del retorno
        try {
            //locales auxiliares para extraer la informacion del archivo
            String code, nom, horario, aula,  dia;
            LocalDate fechIn, fechFn;
            int cupos, disp;
           
            String Reg[];//para tomar la linea String como vector de datos y facilitar el trabajo con el registro
            //se abre el archivo modo lectura y se imprime el mensaje de apertura que retorna
            JOptionPane.showMessageDialog(null, "" + objArc.AbrirArchivoModoLectura("Cursos.txt"));
            //se invoca al metodo de leer registro con 9 atributos para el vector de la linea o registro del archivo plano 
            //se recibe el texto en Reg
            Reg = objArc.LeerRegistro(9);
            //mientras existan datos en el archivo
            while (Reg != null) //mientras not EOF()
            {
               /*los datos del Reg que se obtiene del archivo plano de texto se 
                asignan a las variables auxiliares locales para su facil manejo 
                como posiciones del vector String*/
                code  = Reg[0];
                nom = Reg[1];
                horario = Reg[2];
                aula = Reg[3];
                dia = Reg[4];
                cupos = Integer.parseInt(Reg[5]);
                disp = Integer.parseInt(Reg[6]);
                fechIn = LocalDate.parse(Reg[7]);
                fechFn =LocalDate.parse(Reg[8]);
               
                Cursos objC = new Cursos(code, nom, horario, aula, dia, cupos, disp, fechIn, fechFn);
                if(Buscar(mat,MaxF, MaxC, code)==false)
                {
                   texto = texto + objC.toString() + "\n";
                }
                Reg = objArc.LeerRegistro(9);
            }//fin mientras  
            objArc.CerrarArchivoModoLectura();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "***Archivo leído y cerrado correctamente*****");
        }
        return texto;    
}//Fin CursosArchivoNoEstenEnMatriz

//metodo para organizar las filas de la matriz en orden descendente por codigo
public Object[][] organizarPorIdPorFilas(Object[][] matriz,int maxF, int maxC){
        for (int i = 0; i < maxF ; i++) {//ciclo externo de filas porque se esta recorriendo por filas
            for (int j = 0; j < maxC-1; j++) {//ciclo hasta la penultima columna para el metodo de organizacion elegido
                for (int k = j + 1; k < maxC; k++) {//ciclo k interno rapido para moverse por todas las columnas comparando con j
                    if(((Cursos)matriz[i][j]).getIdCurso().compareTo(((Cursos)matriz[i][k]).getIdCurso()) > 0){
                        Object temp = matriz[i][k];//se hace el intercambio de la informacion
                        matriz[i][k] = matriz[i][j];
                        matriz[i][j] = temp;
                    }
                }
            }
        }
        return matriz;
    }
    















//datos para no tener que ingresar todo
    public Object[][] PruebaEscritorio(Object mat[][])//para matriz de cursos de 3*3
    {
        DateTimeFormatter formatoFec = DateTimeFormatter.ofPattern("dd/MM/yyyy"); 
        mat[0][0]=new Cursos("1010","Pintura","10-12","L201","lunes",40,0,LocalDate.parse("24/10/2024",formatoFec),LocalDate.parse("24/11/2024",formatoFec));
    	mat[0][1]=new Cursos("1030","Ceramica","10-12","M201","martes",50,1,LocalDate.parse("01/10/2024",formatoFec),LocalDate.parse("20/10/2024",formatoFec));
        mat[0][2]=new Cursos("1020","Piano","12-14","L201","martes",40,10,LocalDate.parse("10/10/2024",formatoFec),LocalDate.parse("10/12/2024",formatoFec));
        mat[1][0]=new Cursos("1040","Guitarra","10-12","M201","miercoles",50,0,LocalDate.parse("02/10/2024",formatoFec),LocalDate.parse("02/11/2024",formatoFec));
    	mat[1][1]=new Cursos("1060","GuitarraElectrica","10-12","K201","jueves",40,0,LocalDate.parse("20/10/2024",formatoFec),LocalDate.parse("20/11/2024",formatoFec));
        mat[1][2]=new Cursos("1050","TecnicaVocal","12-14","K201","viernes",50,10,LocalDate.parse("01/10/2024",formatoFec),LocalDate.parse("20/11/2024",formatoFec));
        mat[2][0]=new Cursos("1090","Flauta","10-12","N201","miercoles",50,3,LocalDate.parse("02/10/2024",formatoFec),LocalDate.parse("02/11/2024",formatoFec));
    	mat[2][1]=new Cursos("1080","Teatro","10-12","N201","jueves",50,5,LocalDate.parse("15/10/2024",formatoFec),LocalDate.parse("15/11/2024",formatoFec));
        mat[2][2]=new Cursos("1070","composicion","12-14","N201","viernes",40,0,LocalDate.parse("02/10/2024",formatoFec),LocalDate.parse("02/11/2024",formatoFec));
        
        return mat;
    }

}
